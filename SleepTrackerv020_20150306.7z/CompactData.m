clear
%%http://www.mathworks.com/matlabcentral/answers/27408-reading-a-csv-file-with-header-and-times
%%https://www.gnu.org/software/octave/doc/interpreter/Timing-Utilities.html

rescan = 1;  % 0-do not rescan, 1-rescan data
MAX_BUFFER = 100000;
total2read = 2300000;
formatSpec = '%s %*s %f %f %f';
filename = 'E.txt';
filedata = 'E_data.mat';
things2save = 'T','F','xm','ym','zm';
if MAX_BUFFER > total2read
  MAX_BUFFER = total2read;
end
tCol = 1;
xCol = 2;
yCol = 3;
zCol = 4;
T=[];
F=[];
fidData = fopen(filedata); %if data exist do not rescan unless rescan = 1;
if ~fidData || rescan
  fid = fopen(filename);
  head=1;
  tail=1;
  keepFeeding = 1;
  j=0;
  while ~feof(fid) && (total2read>0)
      DATA = textscan(fid,formatSpec, MAX_BUFFER, 'delimiter' , ',');
      if length(DATA{1,1}) && (total2read>0)
        T=[T;DATA{:,tCol}];
        F=[F;[DATA{:,xCol},DATA{:,yCol},DATA{:,zCol}]];
        samplesRead = length(DATA{1,1});
        total2read = total2read - samplesRead;
        clear DATA;
        for i = 1:(samplesRead-1)
          pastTime = strptime(T(i), "%Y/%m/%d %T").sec;
          currentTime = strptime(T(i+1), "%Y/%m/%d %T").sec;
          if (pastTime == currentTime)
            tail=tail+1;
          else
            j=j+1;
            pastTime = T(i+1);
            xm(j) = mean(F(head:tail,1),1);
            ym(j) = mean(F(head:tail,2),1);
            zm(j) = mean(F(head:tail,3),1);
            tail = tail+1;
            head = tail;
          end
        end
      end
  end
  fclose(fid);
else
  fclose(fidData);
  load(filedata);  
end
save(filedata, things2save);
clear T F;
%DisplayRaw
%DeltaRectify
