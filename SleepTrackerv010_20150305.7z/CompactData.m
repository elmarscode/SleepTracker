clear
%%http://www.mathworks.com/matlabcentral/answers/27408-reading-a-csv-file-with-header-and-times
%%https://www.gnu.org/software/octave/doc/interpreter/Timing-Utilities.html
MAX_BUFFER = 500000;
formatSpec = '%s %*s %f %f %f';
tCol = 1;
xCol = 2;
yCol = 3;
zCol = 4;

fid = fopen('C.txt');
DATA = textscan(fid,formatSpec, MAX_BUFFER, 'delimiter' , ',');
T=DATA{:,tCol};
F=[DATA{:,xCol},DATA{:,yCol},DATA{:,zCol}];
clear DATA
head=1;
tail=1;
j=1;
for i = 1:(length(T)-1)
  pastTime = strptime(T(i), "%Y/%m/%d %T").sec;
  currentTime = strptime(T(i+1), "%Y/%m/%d %T").sec;
  if (pastTime == currentTime)
    tail=tail+1;
  else
    pastTime = T(i+1);
    xm(j) = mean(F(head:tail,1),1);
    ym(j) = mean(F(head:tail,2),1);
    zm(j) = mean(F(head:tail,3),1);
    tail = tail+1;
    head = tail;
    j=j+1;
  end
end
clear T F
filter
